<template>
    <div>
        <router-link to="/">BACK</router-link>
    </div>
</template>
<script>
export default {
    name: 'sample',
}
</script>